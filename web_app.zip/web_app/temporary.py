import sys
from Naked.toolshed.shell import muterun_js

response = muterun_js('face.js')

if response.exitcode == 0:
  print(response.stdout)
  print(response)
else:
  sys.stderr.write(response.stderr)
import cv2
import datetime, time
from pathlib import Path

def capture_and_save(im):
    s = im.shape
    # Add a timestamp
    # font = cv2.FONT_HERSHEY_SIMPLEX
    # bottomLeftCornerOfText = (10,s[0]-10)
    # fontScale = 1
    # fontColor = (20,20,20)
    # lineType = 2
    #
    # cv2.putText(im,datetime.datetime.now().isoformat().split(".")[0],bottomLeftCornerOfText,font,fontScale,fontColor, lineType)

    m = 0
    # p = Path("images")
    # for imp in p.iterdir():
    #     if imp.suffix == ".png" and imp.stem != "last":
    #         num = imp.stem.split("_")[1]
    #         try:
    #             num = int(num)
    #             if num>m:
    #                 m = num
    #         except:
    #             print("Error reading image number for",str(imp))
    # m +=1
    # lp = Path("images/last.png")
    # if lp.exists() and lp.is_file():
    #     np = Path("images/img_{}.png".format(m))
    #     np.write_bytes(lp.read_bytes())
    f_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    face = f_cascade.detectMultiScale(gray, 1.1, 4)
    if len(face) > 0:
        for (x, y, w, h) in face:
            cropped=im[y:y+h,x:x+w]
            cv2.imshow("image", im[y-10:y + h+10, x-10:x + w+10])
            cv2.waitKey(0)
            #cv2.rectangle(im, (x-10, y-10), (x + w+10, y + h+10), (255, 0, 255), 3)
    cv2.imwrite("images/image.png",cropped)

if __name__=="__main__":
    capture_and_save()
    print("done")
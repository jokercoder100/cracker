'use strict';



const request = require('request');

const fs = require("fs");



// Replace <Subscription Key> with your valid subscription key.

const subscriptionKey = '08e7c390c29a4b23b2e592e3f648deb4';



// You must use the same location in your REST call as you used to get your

// subscription keys. For example, if you got your subscription keys from

// westus, replace "westcentralus" in the URL below with "westus".

const uriBase = 'https://facerecogservices.cognitiveservices.azure.com/face/v1.0/detect';

const imageBuffer = fs.readFileSync('E:/Caliber 2020/caliber_stuff/web_app/images/image.png');

//const imageBuffer = fs.readFileSync('D:/CrackerJack_2020_MyTrial/MyTrial/Smijal.jpg');



const imageUrl =

  'E:/Caliber 2020/caliber_stuff/web_app/images/image.png';

// Request parameters.

const params = {

  'returnFaceId': 'true',

  'returnFaceLandmarks': 'false',

  'returnFaceAttributes': 'age,gender,smile,facialHair,glasses'

};



const options = {

  uri: uriBase,

  qs: params,

  body: imageBuffer,

  headers: {

    'Content-Type': 'application/octet-stream',

    'Ocp-Apim-Subscription-Key': subscriptionKey

  }

};



request.post(options, (error, response, body) => {

  if (error) {

    console.log('Error: ', error);

    return;

  }

  let stringJs = JSON.stringify(JSON.parse(body), null, '  ');

  var ret = body

  var ret1 = ret.replace(']', '');

  var ret2 = ret1.replace('[', '');

  var jsonobject = JSON.parse(ret2);

  console.log('The Face ID is '+jsonobject.faceId);

  //console.log(jsonobject.faceId);

  face_identify(jsonobject.faceId);



});



//Function to get PersonID from Azure Face

function face_identify(faceid) {

  const request = require('request');



  // Replace <Subscription Key> with your valid subscription key.

  const subscriptionKey = '08e7c390c29a4b23b2e592e3f648deb4';



  // You must use the same location in your REST call as you used to get your

  // subscription keys. For example, if you got your subscription keys from

  // westus, replace "westcentralus" in the URL below with "westus".

  const uriBase = 'https://facerecogservices.cognitiveservices.azure.com/face/v1.0/identify';



  const imageUrl =

    'https://upload.wikimedia.org/wikipedia/commons/3/37/Dagestani_man_and_woman.jpg';





  // Request parameters.

  const params = {



  };



  const options = {

    uri: uriBase,

    qs: params,

    body: '{"personGroupId": "caliber_cracker","faceIds":["' + faceid + '"]}',

    headers: {

      'Content-Type': 'application/json',

      'Ocp-Apim-Subscription-Key': subscriptionKey

    }



  };



  request.post(options, (error, response, body) => {

    if (error) {

      console.log('Error: ', error);

      return;

    }

    let jsonResponse = JSON.stringify(JSON.parse(body), null, '  ');

    var candidateid = jsonResponse;

    //console.log(candidateid);

    var candidateidsplit = candidateid.split('candidates')[1];

    var candidateidlegth = candidateidsplit.length;



    if (candidateidlegth > 100) {

      //console.log('1');

      //console.log(jsonResponse);

      //console.log('2');

      var ret = body

      var ret = ret.replace(']', '');

      //console.log('3');

      var ret = ret.replace(']', '');

      //console.log('4');

      var ret = ret.replace('[', '');

      //console.log('5');

      var ret = ret.replace('[', '');

      //console.log('6');

      var jsonobject = JSON.parse(ret);

      //console.log('9');



      console.log('The person ID is ' + jsonobject.candidates.personId);

      face_get_person(jsonobject.candidates.personId);

      //console.log(jsonobject.candidates.personId);

      //console.log(jsonobject.candidates.personId);



    } else {

      console.log('The person is a stranger');

      return



    }





  });

}





//Function to get Person Name from Azure Face

function face_get_person(personid) {

  const request = require('request');



  // Replace <Subscription Key> with your valid subscription key.

  const subscriptionKey = '08e7c390c29a4b23b2e592e3f648deb4';



  // You must use the same location in your REST call as you used to get your

  // subscription keys. For example, if you got your subscription keys from

  // westus, replace "westcentralus" in the URL below with "westus".

  const uriBase = 'https://facerecogservices.cognitiveservices.azure.com/face/v1.0/persongroups/caliber_cracker/persons/89167063-523e-410f-87bc-8b3bd8d2ffcd';



  const imageUrl =

    'https://upload.wikimedia.org/wikipedia/commons/3/37/Dagestani_man_and_woman.jpg';

  // Request parameters.

  const params = {

    'personGroupId': 'caliber_cracker',

    'personId': personid



  };



  const options = {

    uri: uriBase,

    qs: params,

    headers: {

      'Ocp-Apim-Subscription-Key': subscriptionKey

    }

  };



  request.get(options, (error, response, body) => {

    if (error) {

      console.log('Error: ', error);

      return;

    }

    let jsonResponse = JSON.stringify(JSON.parse(body), null, '  ');

    var jsonValue=JSON.parse(body)

    console.log('The Person Name is '+jsonValue.name);



  });

}
from flask import Flask, render_template, send_from_directory, Response
# from flask_socketio import SocketIO
from pathlib import Path
# from capture import capture_and_save
from camera import Camera
from capture import capture_and_save
import sys
from Naked.toolshed.shell import muterun_js

camera = Camera()
camera.run()

app = Flask(__name__)

@app.route("/r")
def capture():
    im = camera.get_frame(bytes=False)
    capture_and_save(im)
    return render_template("stream.html")

###NODE HANDLING PART###
@app.route("/r/node")
def nodecall():
    #--------#
    response = muterun_js('face.js')

    if response.exitcode == 0:
        print(response.stdout)
    else:
        sys.stderr.write(response.stderr)
    #--------#
    return render_template("stream.html")


def gen(camera):
    while True:
        frame = camera.get_frame()
        yield (b'--frame\r\n'
               b'Content-Type: image/png\r\n\r\n' + frame + b'\r\n')

@app.route("/")
def entrypoint():
    return render_template("stream.html")

@app.route("/video_feed")
def video_feed():
    return Response(gen(camera),
        mimetype="multipart/x-mixed-replace; boundary=frame")

if __name__=="__main__":
    app.run()